# Carte de navigation Jezero

## Installation (une fois, sur le PC)
- Linux : `sudo apt install gdal-bin` puis `pip install -r requirements.txt`
- macOS : `brew install gdal` puis `pip install -r requirements.txt`
- Windows : passer par WSL (Ubuntu), puis faire comme sous Linux

## 1. Construire la carte (internet requis une seule fois)
    chmod +x build_map.sh
    ./build_map.sh                         # zone de 3x3 km autour du site de Perseverance
    HALF=1000 ./build_map.sh               # zone plus petite = plus rapide (2x2 km)
    LON0=77.40 LAT0=18.45 ./build_map.sh   # déplacer l'habitat / le centre

Les fichiers USGS sont lus à distance (/vsicurl) : seule la zone utile est téléchargée.
Si c'est trop lent ou que ça coupe, téléchargez les .tif complets avec `wget -c`, puis :
    SRC_IMG=raw/ortho.tif SRC_DTM=raw/dtm.tif ./build_map.sh

## 2. Zones dangereuses + itinéraire
Éditez `web/data/hazards.geojson` (polygones, ou points avec "radius" en m ; coordonnées en m, habitat = 0,0).
    python3 make_cost.py --target 800 600

## 3. Afficher
    cd web && python3 -m http.server 8000     → http://localhost:8000
Cliquez sur la carte pour obtenir les coordonnées X Y d'une cible.

## Sur le Pi
Copier le dossier `web/` (et `build/` + `make_cost.py` pour le calcul d'itinéraire). Aucun accès internet n'est nécessaire.

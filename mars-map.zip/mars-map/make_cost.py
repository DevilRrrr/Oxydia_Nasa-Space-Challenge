#!/usr/bin/env python3
"""
make_cost.py — Carte de coût + calcul d'itinéraire (A* / Dijkstra sur grille).

Entrées : build/slope.tif (de build_map.sh), web/data/hazards.geojson (facultatif)
Sorties : build/cost.tif, web/data/route.geojson

Repère : mètres locaux, (0,0) = habitat, X = Est, Y = Nord.

Exemples :
  python3 make_cost.py --target 800 600
  python3 make_cost.py --start 0 0 --target -900 400 --slope-max 18 --cell 2
"""
import argparse, json, math, os, time
import numpy as np
import rasterio
from rasterio.features import rasterize
from rasterio.transform import from_origin
from shapely.geometry import shape, Point
from skimage.graph import route_through_array
from skimage.measure import approximate_polygon

p = argparse.ArgumentParser()
p.add_argument("--start", nargs=2, type=float, default=[0, 0], metavar=("X", "Y"))
p.add_argument("--target", nargs=2, type=float, required=True, metavar=("X", "Y"))
p.add_argument("--cell", type=float, default=2.0, help="taille de case de la grille (m)")
p.add_argument("--slope-max", type=float, default=20.0, help="pente infranchissable (degrés)")
p.add_argument("--hazards", default="web/data/hazards.geojson")
p.add_argument("--out", default="web/data/route.geojson")
a = p.parse_args()

# ---------- 1. Pente rééchantillonnée sur la grille de calcul ----------
with rasterio.open("build/slope.tif") as src:
    f = max(1, round(a.cell / src.res[0]))
    a.cell = f * src.res[0]
    full = src.read(1, masked=True).filled(np.nan).astype("f4")
    xmin, ymax = src.bounds.left, src.bounds.top
    crs = src.crs
h, w = full.shape[0] // f, full.shape[1] // f
# Prudent : une case prend la pente la plus forte qu'elle contient (NaN = pas de donnée -> interdit)
s = full[:h * f, :w * f].reshape(h, f, w, f).max(axis=(1, 3))
T = from_origin(xmin, ymax, a.cell, a.cell)

# ---------- 2. Coût ----------
cost = 1.0 + 9.0 * (s / a.slope_max) ** 2          # 1 sur le plat, 10 à la limite
cost[(s >= a.slope_max) | np.isnan(s)] = np.inf    # infranchissable

# Zones dangereuses / obstacles (polygones, ou points avec propriété "radius" en m)
n_haz = 0
if os.path.exists(a.hazards):
    geoms = []
    for ft in json.load(open(a.hazards))["features"]:
        g = shape(ft["geometry"])
        if g.geom_type == "Point":
            g = g.buffer(ft.get("properties", {}).get("radius", 10))
        geoms.append(g.buffer(5))                   # marge de sécurité 5 m
    if geoms:
        mask = rasterize(geoms, out_shape=cost.shape, transform=T, fill=0, default_value=1).astype(bool)
        cost[mask] = np.inf
        n_haz = len(geoms)

with rasterio.open("build/cost.tif", "w", driver="GTiff", height=h, width=w, count=1,
                   dtype="float32", crs=crs, transform=T, compress="deflate") as o:
    o.write(np.where(np.isinf(cost), -1, cost).astype("f4"), 1)

# ---------- 3. Itinéraire ----------
def rc(x, y):
    r, c = int((ymax - y) / a.cell), int((x - xmin) / a.cell)
    if not (0 <= r < h and 0 <= c < w):
        raise SystemExit(f"Point ({x},{y}) hors de la carte")
    return r, c

def xy(r, c):
    return [round(xmin + (c + .5) * a.cell, 2), round(ymax - (r + .5) * a.cell, 2)]

r0, r1 = rc(*a.start), rc(*a.target)
for name, (r, c) in (("départ", r0), ("cible", r1)):
    if np.isinf(cost[r, c]):
        raise SystemExit(f"Le point de {name} est sur une case infranchissable (pente/danger).")

t = time.time()
path, total = route_through_array(cost, r0, r1, fully_connected=True, geometric=True)
dt = time.time() - t
if not np.isfinite(total):
    raise SystemExit("Aucun itinéraire possible : la cible est isolée par des zones infranchissables.")

pts = np.array([xy(r, c) for r, c in path])
pts = approximate_polygon(pts, tolerance=a.cell)    # simplification du tracé
length = float(np.sum(np.hypot(*np.diff(pts, axis=0).T)))
direct = math.dist(a.start, a.target)
max_slope = float(np.nanmax([s[r, c] for r, c in path]))

route = {"type": "FeatureCollection", "features": [{
    "type": "Feature",
    "geometry": {"type": "LineString", "coordinates": pts.tolist()},
    "properties": {"length_m": round(length), "direct_m": round(direct),
                   "max_slope_deg": round(max_slope, 1), "compute_s": round(dt, 3),
                   "start": a.start, "target": a.target}}]}
os.makedirs(os.path.dirname(a.out), exist_ok=True)
json.dump(route, open(a.out, "w"))

print(f"Grille {w}x{h} ({a.cell} m), {n_haz} zone(s) dangereuse(s), "
      f"{np.isinf(cost).mean()*100:.1f}% infranchissable")
print(f"Itinéraire : {length:.0f} m (ligne droite {direct:.0f} m), pente max {max_slope:.1f}°, "
      f"calculé en {dt:.2f} s  ->  {a.out}")

#!/usr/bin/env bash
# =============================================================================
#  build_map.sh — Construit la carte locale de Jezero (image HiRISE + topographie)
#
#  Sortie (dossier web/) :
#    tiles/img     image HiRISE 25 cm/px
#    tiles/relief  relief coloré + ombrage (depuis le MNT 1 m)
#    tiles/slope   pentes dangereuses (calque transparent)
#    data/meta.json  géoréférencement pour Leaflet
#  et dans build/ : dtm.tif, slope.tif ... (utilisés par make_cost.py)
#
#  Repère : mètres locaux, origine (0,0) = habitat (LON0, LAT0), X = Est, Y = Nord.
#
#  Usage :   ./build_map.sh
#  Options (variables d'environnement) :
#    LON0=77.4298 LAT0=18.4663 HALF=1500 ./build_map.sh
#    SRC_IMG=raw/ortho.tif SRC_DTM=raw/dtm.tif ./build_map.sh   (fichiers déjà téléchargés)
# =============================================================================
set -euo pipefail
cd "$(dirname "$0")"

# ---------- Paramètres ----------
LON0=${LON0:-77.4298}      # centre de la zone = habitat (ici : site d'atterrissage de Perseverance)
LAT0=${LAT0:-18.4663}
HALF=${HALF:-1500}         # demi-côté de la zone en mètres (1500 -> zone de 3 x 3 km)
RES_IMG=${RES_IMG:-0.25}   # résolution de l'image (m/px)
RES_DTM=${RES_DTM:-1}      # résolution du MNT (m/px)
JOBS=${JOBS:-$(nproc 2>/dev/null || echo 4)}

USGS=https://planetarymaps.usgs.gov/mosaic/mars2020_trn/HiRISE
SRC_IMG=${SRC_IMG:-/vsicurl/$USGS/JEZ_hirise_soc_006_orthoMosaic_25cm_Eqc_latTs0_lon0_first.tif}
SRC_DTM=${SRC_DTM:-/vsicurl/$USGS/JEZ_hirise_soc_006_DTM_MOLAtopography_DeltaGeoid_1m_Eqc_latTs0_lon0_blend40.tif}

B=build; W=web
mkdir -p "$B" "$W/tiles" "$W/data"

# Lecture distante efficace (/vsicurl lit seulement les morceaux nécessaires)
export GDAL_DISABLE_READDIR_ON_OPEN=EMPTY_DIR GDAL_HTTP_MAX_RETRY=5 GDAL_HTTP_RETRY_DELAY=3 \
       CPL_VSIL_CURL_CHUNK_SIZE=4194304 GDAL_CACHEMAX=1024 GDAL_NUM_THREADS=ALL_CPUS

# Projection locale en vrais mètres, centrée sur l'habitat (sphère Mars IAU, R = 3396190 m)
LOCAL="+proj=eqc +lat_ts=$LAT0 +lat_0=$LAT0 +lon_0=$LON0 +R=3396190 +units=m +no_defs"
TE="-$HALF -$HALF $HALF $HALF"
CO="-co COMPRESS=DEFLATE -co TILED=YES -co BIGTIFF=IF_SAFER"
G2T=$(command -v gdal2tiles.py || command -v gdal2tiles)

step(){ echo -e "\n\033[1;33m==> $*\033[0m"; }

# ---------- 1. Découpe + reprojection ----------
step "1/6 Découpe du MNT ($((2*HALF)) m x $((2*HALF)) m, $RES_DTM m/px)"
gdalwarp -overwrite -t_srs "$LOCAL" -te $TE -tr $RES_DTM $RES_DTM -r bilinear \
  -ot Float32 -dstnodata -9999 $CO "$SRC_DTM" "$B/dtm.tif"

step "2/6 Découpe de l'image HiRISE ($RES_IMG m/px) — peut prendre quelques minutes"
gdalwarp -overwrite -t_srs "$LOCAL" -te $TE -tr $RES_IMG $RES_IMG -r bilinear \
  -dstnodata 0 $CO "$SRC_IMG" "$B/img_raw.tif"
# Conversion en 8 bits avec étirement du contraste (2e-98e percentile)
read P2 P98 < <(python3 - "$B/img_raw.tif" <<'EOF'
import sys, numpy as np, rasterio
with rasterio.open(sys.argv[1]) as d:
    f = max(1, d.width // 2000)
    a = d.read(1, out_shape=(d.height // f, d.width // f)).astype("f8")
    a = a[a > 0]
    print(*np.percentile(a, [2, 98]) if a.size else (0, 255))
EOF
)
gdal_translate -q -ot Byte -scale "$P2" "$P98" 1 255 -a_nodata 0 $CO "$B/img_raw.tif" "$B/img.tif"

# ---------- 2. Produits topographiques ----------
step "3/6 Ombrage, pentes, relief coloré"
gdaldem hillshade -q -multidirectional -z 2 -compute_edges "$B/dtm.tif" "$B/hillshade.tif" $CO
gdaldem slope     -q -compute_edges "$B/dtm.tif" "$B/slope.tif" $CO

cat > "$B/ramp_alt.txt" <<'EOF'
nv    0   0   0   0
0%   40  20  90 255
20%  30  90 170 255
40%  60 160 120 255
60%  220 200  90 255
80%  200 110  50 255
100% 250 245 240 255
EOF
gdaldem color-relief -q -alpha "$B/dtm.tif" "$B/ramp_alt.txt" "$B/color.tif" $CO

# Pentes : transparent < 15°, jaune 15-20°, orange 20-25°, rouge > 25°
cat > "$B/ramp_slope.txt" <<'EOF'
nv   0   0   0   0
0    0   0   0   0
14.9 0   0   0   0
15  255 230   0 110
20  255 140   0 160
25  230   0   0 200
90  160   0   0 220
EOF
gdaldem color-relief -q -alpha -nearest_color_entry "$B/slope.tif" "$B/ramp_slope.txt" "$B/slope_rgba.tif" $CO

# Fusion relief coloré x ombrage
python3 - "$B" <<'EOF'
import sys, numpy as np, rasterio
b = sys.argv[1]
with rasterio.open(f"{b}/color.tif") as c, rasterio.open(f"{b}/hillshade.tif") as h:
    rgba = c.read().astype("f4"); hs = h.read(1).astype("f4") / 255
    prof = c.profile
rgba[:3] *= 0.35 + 0.75 * hs
rgba = np.clip(rgba, 0, 255).astype("u1")
with rasterio.open(f"{b}/relief.tif", "w", **prof) as o:
    o.write(rgba)
EOF

# ---------- 3. Alignement des grilles pour les tuiles ----------
step "4/6 Alignement des couches sur la grille de l'image"
for L in relief slope_rgba; do
  gdalwarp -q -overwrite -te $TE -tr $RES_IMG $RES_IMG -r bilinear $CO "$B/$L.tif" "$B/${L}_hr.tif"
done

# ---------- 4. Tuiles ----------
step "5/6 Génération des tuiles ($JOBS processus)"
for pair in "img:$B/img.tif" "relief:$B/relief_hr.tif" "slope:$B/slope_rgba_hr.tif"; do
  name=${pair%%:*}; src=${pair#*:}
  rm -rf "$W/tiles/$name"
  "$G2T" -q -p raster --xyz -w none -r average --processes="$JOBS" "$src" "$W/tiles/$name"
done

# ---------- 5. Métadonnées pour Leaflet ----------
step "6/6 Métadonnées"
python3 - "$W/data/meta.json" "$HALF" "$RES_IMG" "$LON0" "$LAT0" "$W/tiles/img" <<'EOF'
import sys, json, math, os
out, half, res, lon0, lat0, tdir = sys.argv[1], float(sys.argv[2]), float(sys.argv[3]), float(sys.argv[4]), float(sys.argv[5]), sys.argv[6]
size = round(2 * half / res)
maxz = max(int(d) for d in os.listdir(tdir) if d.isdigit())
json.dump(dict(xmin=-half, ymax=half, size_m=2*half, res=res, size_px=size, maxZoom=maxz,
               lon0=lon0, lat0=lat0, R=3396190), open(out, "w"), indent=2)
print(open(out).read())
EOF

echo -e "\n\033[1;32mTerminé.\033[0m  Ensuite :  python3 make_cost.py --target 800 600   puis   cd web && python3 -m http.server 8000"
